﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Attendance_Monitoring_System_v6._0
{
    public class Registration
    {
        public string student_number { get; set; }
        public string first_name { get; set; }
        public string middle_name { get; set; }
        public string last_name { get; set; }
        public string section { get; set; }
        public string contact_number { get; set; }
    }
}
