﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Attendance_Monitoring_System_v6._0
{
    public partial class admin_report : UserControl
    {
        public admin_report()
        {
            InitializeComponent();
        }
    }
}
